function SayHello() {
    var x = "hello world";
    alert(x);
}
