function SayHello() {
	let x = "hello world";
	alert(x);
}
