var app;
(function (app) {
    angular.module("productManagement", []);
})(app || (app = {}));
