var app;
(function (app) {
    angular.module("productManagement", ["common.services",
        "productResourceMock"]);
})(app || (app = {}));
