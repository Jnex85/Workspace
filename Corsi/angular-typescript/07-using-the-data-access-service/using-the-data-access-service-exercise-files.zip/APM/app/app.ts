module app {
	angular.module("productManagement",
		 			["common.services",
				     "productResourceMock"]);
}