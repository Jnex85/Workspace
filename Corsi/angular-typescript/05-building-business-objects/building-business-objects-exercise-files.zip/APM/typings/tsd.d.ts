/// <reference path="angularjs/angular.d.ts" />
/// <reference path="jquery/jquery.d.ts" />
